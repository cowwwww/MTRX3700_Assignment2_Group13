"""Boundary tests for PCM conversion and the short-recording template path."""
import unittest
from pathlib import Path
import numpy as np
from train_recordings import decode_pcm, centres, pack, fit
from template_common import decision
from recording_dataset import recording_metadata, take_folds, balanced_values


class RecordingTests(unittest.TestCase):
    def test_signed_24_bit_extremes_and_stereo_order(self):
        words = [-8388608, -1, 0, 8388607]
        raw = b''.join((v & 0xffffff).to_bytes(3, 'little') for v in words)
        result = decode_pcm(raw, 3, 2)
        np.testing.assert_array_equal(result, np.array(words).reshape(2, 2)/8388608)

    def test_other_pcm_widths(self):
        np.testing.assert_array_equal(decode_pcm(bytes([0,128,255]),1,1).ravel(), [-1,0,127/128])
        for width, dtype in [(2,'<i2'),(4,'<i4')]:
            bound = 1 << (8*width-1)
            values = np.array([-bound,-1,0,bound-1],dtype=dtype)
            np.testing.assert_array_equal(decode_pcm(values.tobytes(),width,1).ravel(), values.astype(float)/bound)

    def test_short_recordings_keep_four_templates_without_fake_samples(self):
        values = np.array([[100+i for i in range(24)], [500+i for i in range(24)]])
        result = centres(values)
        self.assertEqual(result.shape, (4,24))
        for row in result:
            self.assertTrue(any(np.array_equal(row, original) for original in values))
        self.assertEqual(pack(values[0])[-4:], '0064')
        self.assertEqual(pack(values[0])[:4], '007b')

    def test_unsigned_distance_and_exact_ratio_boundary(self):
        templates = np.array([[[100]], [[200]], [[300]], [[400]]], dtype=np.uint16)
        self.assertEqual(decision(np.array([0],dtype=np.uint16),templates), (0,False,127))
        # d1/d2=7/10 is accepted; one count nearer the competing class is rejected.
        templates = np.array([[[0]], [[17]], [[100]], [[200]]])
        self.assertEqual(decision([7],templates), (0,False,76))
        self.assertTrue(decision([8],templates)[1])

    def test_layout_and_new_speaker(self):
        for speaker in ['m','x']:
            r = recording_metadata(Path(f'sample_2/high_pitch/ee/ee-{speaker}-002.wav'), Path('sample_2'))
            self.assertEqual((r['condition'],r['label'],r['speaker'],r['take']),('high_pitch','ee',speaker,2))
        with self.assertRaises(ValueError):
            recording_metadata(Path('sample_2/normal/ah/ee-m-001.wav'),Path('sample_2'))

    def test_takes_conditions_and_slices_stay_in_one_fold(self):
        records = []
        for condition in ['normal','far']:
            for take in ['001-part01','001-part02','002']:
                r = recording_metadata(Path(f'data/{condition}/ee/ee-m-{take}.wav'),Path('data'))
                r['sha256'] = str(len(records));records.append(r)
        folds = take_folds(records)
        self.assertEqual([folds[i] for i in range(6)], [0,0,1,0,0,1])
        records[2]['sha256'] = records[0]['sha256']
        with self.assertRaises(ValueError):
            take_folds(records)

    def test_balance_keeps_a_new_speaker_and_far_condition_represented(self):
        records = [dict(speaker='m',condition='normal',source_group='m/ee/1'),
                   dict(speaker='m',condition='far',source_group='m/ee/1'),
                   dict(speaker='x',condition='normal',source_group='x/ee/1')]
        rows = [(0,0,np.full(24,10)) for _ in range(20)]
        rows += [(0,1,np.full(24,200)),(0,2,np.full(24,900))]
        values = balanced_values(rows,records,0)
        self.assertEqual([(values[:,0]==v).sum() for v in [10,200,900]], [20,20,20])
        all_rows = [(c,t,f+c*2000) for c in range(4) for _,t,f in rows]
        self.assertEqual(fit(all_rows,records).shape, (4,4,24))


if __name__ == '__main__':
    unittest.main()
