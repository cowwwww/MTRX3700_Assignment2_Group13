"""Condition/speaker metadata and whole-take splitting for the sample_2 layout."""
from collections import defaultdict
import re
import numpy as np

LABELS = ['ee', 'ah', 'oo', 'aw']
CONDITIONS = ['normal', 'high_pitch', 'loud', 'far']


def recording_metadata(path, root):
    relative = path.relative_to(root)
    if len(relative.parts) != 3:
        raise ValueError(f'{relative}: expected condition/vowel/vowel-speaker-take.wav')
    condition, label = (x.lower() for x in relative.parts[:2])
    if condition not in CONDITIONS or label not in LABELS:
        raise ValueError(f'{relative}: unknown condition or vowel directory')
    # Optional suffix groups slices of ONE original take, e.g. ee-m-001-part01.wav.
    match = re.fullmatch(r'(ee|ah|oo|aw)-([a-z]+)-(\d+)(?:-([a-z0-9_]+))?', path.stem.lower())
    if not match or match[1] != label:
        raise ValueError(f'{relative}: filename must match the vowel directory, e.g. {label}-m-001.wav')
    speaker, take = match[2], int(match[3])
    return dict(condition=condition, label=label, class_index=LABELS.index(label),
                speaker=speaker, take=take, segment=match[4],
                source_group=f'{speaker}/{label}/{take}')


def take_folds(records):
    """Keep every frame/slice and condition variant of a speaker/vowel/take together."""
    groups = defaultdict(set)
    for record in records:
        groups[record['speaker'], record['label']].add(record['take'])
    assigned = {}
    for key, takes in groups.items():
        # A speaker with only one take contributes to training, not claimed validation.
        for i, take in enumerate(sorted(takes)):
            assigned[(*key, take)] = i % 2 if len(takes) >= 2 else None
    result = {i: assigned[r['speaker'], r['label'], r['take']] for i, r in enumerate(records)}
    hashes = defaultdict(set)
    for i, record in enumerate(records):
        hashes[record['sha256']].add(result[i])
    if any(len(values) > 1 for values in hashes.values()):
        raise ValueError('Identical WAVs occur in different folds. Give slices/copies of one source the same take number.')
    return result


def balance(groups):
    """Deterministic equal-weight sampling; repeats change weights, not evidence counts."""
    size = max(map(len, groups))
    return np.concatenate([g[np.arange(size)*len(g)//size] for g in groups])


def balanced_values(rows, records, label):
    cells = defaultdict(lambda: defaultdict(list))
    for c, token, feature in rows:
        if c == label:
            r = records[token]
            cells[r['speaker'], r['condition']][r['source_group']].append(feature)
    if not cells:
        raise ValueError(f'No training frames for {LABELS[label]}')
    # Equal observed speaker/condition cells; equal original takes inside each cell.
    # Splitting a take into extra files cannot buy extra training weight.
    return balance([balance([np.array(takes[key]) for key in sorted(takes)])
                    for _, takes in sorted(cells.items())])
