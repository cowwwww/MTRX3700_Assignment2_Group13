# V11：使用 V10 中途备份生成的元音模板

这版已完成训练，可以打开 shine_sing.qpf，在 Quartus 中执行 Start Compilation，然后烧录新生成的 output_files/shine_sing.sof。无需重新运行语音训练。此次没有运行 Quartus，没有附带新 SOF。

数据来自 V10 的 Train_backup，而非 sample_3。原 V10 和 Train_backup 均未修改。

本次使用 48 段清单中已完成提取、且被 transcript 确认的 26 段录音。第 27 段未完整提取，已排除；其余未提取录音也已排除。

- 说话人：c、m。
- 四种元音：ee、ah、oo、aw。
- far 和 high_pitch：四种元音均有覆盖。
- loud：只包含两段 ah；normal 没有已完成提取的数据。
- 训练使用 463 个能量筛选后的特征帧，仍保持四类、每类四个模板、每个模板 24 维。
- 继续复用 Ed 的 SAD 聚类和模板导出函数，以及 V10 的实际 RTL 特征。

留出验证按说话人/元音/录音编号分组，同一来源的各条件保持同一分组。377 个验证帧中 311 个正确识别，66 个拒识，没有接受后分错元音的帧。总正确识别率为 82.5%，拒识率为 17.5%。这是已录入说话人的另一录音验证；不能代表陌生人或现场麦克风识别效果，也没有覆盖 normal 的现场表现。

已通过工程文件/课程源文件哈希检查以及一次 tb_recording_classifier 的 ModelSim 仿真。没有执行完整回归或 Quartus 编译。

## 文件

- rtl/templates.svh 和 rtl/templates.hex：已训练模板。
- rtl/templates_training.json：训练指标及被排除的录音清单。
- assets/recordings：选中的完整录音清单、特征和分类器检查输入。
- build/recordings：原始中途特征缓存和 48 段录音清单，供复现使用。
- build/extraction_transcript.txt：备份的提取日志，保留原始进度信息。

如确实需要从这份缓存重新生成相同模板，在工程根目录运行：

```powershell
python tools/train_recordings.py --stage train --sim modelsim --allow-partial
python tools/check_project.py --require-trained
```

不要使用不带 --stage train 的训练命令复现这份缓存，它会准备新数据并覆盖缓存。新增语料需要重新提取特征和训练；本包未包含原始 WAV，届时用 --samples 指定实际语料目录。
