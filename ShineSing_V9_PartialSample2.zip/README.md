# V9 原工程设置 + sample_2 中途备份模板

本版从 V9_Sample_Trained 复制硬件 RTL、Quartus QSF 和 SDC，替换三份模板文件与对应分类器检查数据。使用的是 V11_Backup_Trained 已生成的 sample_2 模板，不需要重新训练。

在 Quartus 打开本目录的 shine_sing.qpf，执行 Processing → Start Compilation。完成后烧录新生成的 output_files/shine_sing.sof。此包没有旧 SOF，也没有编译缓存；此次没有执行 Quartus 编译。

与原 V9 的硬件 RTL 对比，只有 templates.svh、templates.hex 和 templates_training.json 不同。QSF 和 SDC 与原 V9 完全一致。V11 本来也使用同一套硬件逻辑，因此这个版本不能保证缩短布局布线时间。

模板来自 V10 的 Train_backup，使用 26 段完整录音、463 个筛选后的特征帧，四类元音每类四个模板。far 和 high_pitch 覆盖四类；loud 仅有 ah；normal 尚未提取。留出验证的正确识别率为 82.5%，拒识率为 17.5%，不能代表现场麦克风效果。

模板、硬件 RTL 与 V11 已通过的分类器一致性仿真相同，本次只核对工程文件与模板元数据，不重复运行仿真。V9 旧编译结果不适用于此包，没有将旧报告或旧 SOF 当作本版结果。

本版保留 V9 原训练工具，未附带原始 WAV。当前模板已训练，无需运行这些训练工具；若将来重训 sample_2，应使用 V10/V11 的相应训练流程。
